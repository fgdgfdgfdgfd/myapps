# MyApp - Getting Started / Начните здесь

**English** | [Русский](#russian-section)

---

## English

# Getting Started with MyApp (5 Minutes)

## 🎯 What is MyApp?

MyApp is a **command-line utility** that displays your system information, similar to popular tools like `neofetch` or `screenfetch`.

### What MyApp Shows:
- 🖥️ Operating System name and version
- 🔧 Linux Kernel version
- 💻 CPU model and number of cores
- 🧠 RAM size
- 💾 Disk usage
- ⏱️ System uptime
- 🐚 Current shell
- 👤 Current user
- 🕐 Date and time

---

## ⚡ Super Quick Start (2 minutes)

### For Ubuntu/Debian:

```bash
# 1. Download (10 seconds)
wget https://github.com/fgdgfdgfdgfd/myapps/archive/main.zip
unzip main.zip
cd myapps-main

# 2. Install (30 seconds)
chmod +x install-myapp.sh
./install-myapp.sh

# 3. Restart terminal
exit

# 4. Use (5 seconds)
myapp
```

---

## 📋 What You'll See After Installation

```
    ╔═══════════════════╗
    ║    MyApp Info     ║
    ╚═══════════════════╝

User..................... user@ubuntu
OS....................... Ubuntu 24.04.3 LTS
Kernel................... 6.8.0-1012-generic
CPU...................... Intel(R) Core(TM) i7-9700K (8 cores)
RAM...................... 16Gi
Disk..................... 50G / 100G
Uptime................... 5d 3h 42m
Shell.................... bash
Time..................... 2025-12-07 14:23:15
```

---

## 🚀 Installation Methods (Choose One)

### Method 1: Automatic Installation (Recommended)

```bash
# Download the package
wget https://github.com/fgdgfdgfdgfd/myapps/archive/main.zip
unzip main.zip
cd myapps-main

# Run the smart installer
chmod +x install-myapp.sh
./install-myapp.sh

# Reload terminal
exit
```

**What it does automatically:**
- ✅ Checks Python version
- ✅ Checks pip installation
- ✅ Checks setuptools
- ✅ Installs missing packages
- ✅ Installs MyApp
- ✅ Adds MyApp to PATH
- ✅ Tests the installation

### Method 2: Using System Package (Ubuntu/Debian)

```bash
# Download the .deb package
wget https://github.com/fgdgfdgfdgfd/myapps/releases/download/v1.0.0/myapp_1.0.0_all.deb

# Install
sudo dpkg -i myapp_1.0.0_all.deb

# Done! Use it
myapp
```

### Method 3: Manual Installation

```bash
# Clone or download the repository
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Check dependencies
python3 -m myapp.dependencies

# Install from source
cd myapp
pip install -e .

# Add to PATH if needed
export PATH="$HOME/.local/bin:$PATH"

# Use
myapp
```

---

## 💻 Basic Usage

### Show System Information

```bash
# Show in system language (or English by default)
myapp

# Show in Russian
myapp ru

# Show in English
myapp en

# Show help
myapp --help
```

---

## ⚠️ Troubleshooting for Beginners

### Problem: Command "myapp" not found

**Solution:**
```bash
# 1. Restart terminal
exit
# Open a new terminal window

# 2. Check if installed
which myapp

# 3. If still not found, add to PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Problem: Python not found

**Solution:**
```bash
# For Ubuntu/Debian
sudo apt-get update
sudo apt-get install python3 python3-pip

# For macOS
brew install python3

# For Fedora/CentOS
sudo yum install python3 python3-pip
```

### Problem: Permission denied

**Solution:**
```bash
# Use sudo
sudo python3 setup.py install

# Or use pip with --user
pip install --user -e .
```

---

## 📖 Learning More

Once installed, explore these documents:

1. **README.md** - Complete documentation
2. **DOWNLOAD_AND_INSTALL.md** - Download and installation guide
3. **METHODS_COMPARISON.md** - Compare installation methods
4. **OS_SUPPORT.md** - OS-specific instructions
5. **IMPROVEMENTS.md** - What's new in v1.0.0

---

## ✅ Verification

After installation, verify everything works:

```bash
# Check that myapp is in PATH
which myapp

# Display help
myapp --help

# Show system info
myapp

# Show in Russian
myapp ru
```

All commands should work without errors.

---

## 🆘 Still Need Help?

1. **Check dependencies:**
   ```bash
   python3 -m myapp.dependencies
   ```

2. **Check installation:**
   ```bash
   pip list | grep myapp
   ```

3. **Read documentation:**
   - See [DOWNLOAD_AND_INSTALL.md](DOWNLOAD_AND_INSTALL.md)
   - See [OS_SUPPORT.md](OS_SUPPORT.md)

4. **Create an issue:**
   - Visit: https://github.com/fgdgfdgfdgfd/myapps/issues

---

---

<a name="russian-section"></a>

# Начните с MyApp (5 минут)

## 🎯 Что такое MyApp?

MyApp - это **утилита командной строки**, которая показывает информацию о вашей системе, похожая на популярные инструменты `neofetch` или `screenfetch`.

### Что показывает MyApp:
- 🖥️ Имя и версия операционной системы
- 🔧 Версия ядра Linux
- 💻 Модель процессора и количество ядер
- 🧠 Размер памяти (RAM)
- 💾 Использование диска
- ⏱️ Время работы системы
- 🐚 Текущий shell
- 👤 Текущий пользователь
- 🕐 Дату и время

---

## ⚡ Быстрый старт (2 минуты)

### Для Ubuntu/Debian:

```bash
# 1. Скачать (10 секунд)
wget https://github.com/fgdgfdgfdgfd/myapps/archive/main.zip
unzip main.zip
cd myapps-main

# 2. Установить (30 секунд)
chmod +x install-myapp.sh
./install-myapp.sh

# 3. Перезагрузить терминал
exit

# 4. Использовать (5 секунд)
myapp
```

---

## 📋 Что вы увидите после установки

```
    ╔═══════════════════╗
    ║      MyApp Info    ║
    ╚═══════════════════╝

Пользователь........ user@ubuntu
ОС.................. Ubuntu 24.04.3 LTS
Ядро................ 6.8.0-1012-generic
Процессор........... Intel(R) Core(TM) i7-9700K (8 ядер)
Память.............. 16Gi
Диск................ 50G / 100G
Uptime.............. 5d 3h 42m
Shell............... bash
Время............... 2025-12-07 14:23:15
```

---

## 🚀 Методы установки (выберите один)

### Метод 1: Автоматическая установка (Рекомендуется)

```bash
# Скачать пакет
wget https://github.com/fgdgfdgfdgfd/myapps/archive/main.zip
unzip main.zip
cd myapps-main

# Запустить умный установщик
chmod +x install-myapp.sh
./install-myapp.sh

# Перезагрузить терминал
exit
```

**Что он делает автоматически:**
- ✅ Проверяет версию Python
- ✅ Проверяет установку pip
- ✅ Проверяет setuptools
- ✅ Устанавливает недостающие пакеты
- ✅ Устанавливает MyApp
- ✅ Добавляет MyApp в PATH
- ✅ Проверяет установку

### Метод 2: Использование системного пакета (Ubuntu/Debian)

```bash
# Скачать .deb пакет
wget https://github.com/fgdgfdgfdgfd/myapps/releases/download/v1.0.0/myapp_1.0.0_all.deb

# Установить
sudo dpkg -i myapp_1.0.0_all.deb

# Готово! Используйте
myapp
```

### Метод 3: Ручная установка

```bash
# Клонировать или скачать репозиторий
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Проверить зависимости
python3 -m myapp.dependencies

# Установить из исходников
cd myapp
pip install -e .

# Добавить в PATH если нужно
export PATH="$HOME/.local/bin:$PATH"

# Использовать
myapp
```

---

## 💻 Основное использование

### Показать информацию о системе

```bash
# Показать на языке системы (или по умолчанию на английском)
myapp

# Показать на русском
myapp ru

# Показать на английском
myapp en

# Показать справку
myapp --help
```

---

## ⚠️ Решение проблем для начинающих

### Проблема: Команда "myapp" не найдена

**Решение:**
```bash
# 1. Перезагрузите терминал
exit
# Откройте новое окно терминала

# 2. Проверьте установку
which myapp

# 3. Если все еще не найдена, добавьте в PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Проблема: Python не найден

**Решение:**
```bash
# Для Ubuntu/Debian
sudo apt-get update
sudo apt-get install python3 python3-pip

# Для macOS
brew install python3

# Для Fedora/CentOS
sudo yum install python3 python3-pip
```

### Проблема: Permission denied

**Решение:**
```bash
# Используйте sudo
sudo python3 setup.py install

# Или используйте pip с --user
pip install --user -e .
```

---

## 📖 Узнайте больше

После установки изучите эти документы:

1. **README.md** - Полная документация
2. **DOWNLOAD_AND_INSTALL.md** - Руководство скачивания и установки
3. **METHODS_COMPARISON.md** - Сравнение методов установки
4. **OS_SUPPORT.md** - Инструкции для конкретной ОС
5. **IMPROVEMENTS.md** - Что нового в v1.0.0

---

## ✅ Проверка

После установки проверьте, что всё работает:

```bash
# Проверить, что myapp в PATH
which myapp

# Показать справку
myapp --help

# Показать информацию о системе
myapp

# Показать на русском
myapp ru
```

Все команды должны работать без ошибок.

---

## 🆘 Нужна дополнительная помощь?

1. **Проверьте зависимости:**
   ```bash
   python3 -m myapp.dependencies
   ```

2. **Проверьте установку:**
   ```bash
   pip list | grep myapp
   ```

3. **Прочитайте документацию:**
   - Смотрите [DOWNLOAD_AND_INSTALL.md](DOWNLOAD_AND_INSTALL.md)
   - Смотрите [OS_SUPPORT.md](OS_SUPPORT.md)

4. **Создайте issue:**
   - Посетите: https://github.com/fgdgfdgfdgfd/myapps/issues

---

**Версия**: 1.0.0  
**Дата**: 2025-12-07  
**Лицензия**: MIT  
**Статус**: ✅ Готово к использованию
