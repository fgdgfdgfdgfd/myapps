English | [Русский](#русский)

---

## English

# MyApp - Download and Installation Guide

## 📥 How to Download MyApp

### Option 1: Download from GitHub (Recommended)

```bash
# Clone the repository
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Or download as ZIP
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main
```

### Option 2: Download Pre-built Package

**For Ubuntu/Debian:**
```bash
# Download .deb package
wget https://github.com/fgdgfdgfdgfd/myapps/releases/download/v1.0.0/myapp_1.0.0_all.deb

# Install
sudo dpkg -i myapp_1.0.0_all.deb
```

### Option 3: Download from Release

Visit: https://github.com/fgdgfdgfdgfd/myapps/releases/v1.0.0

Files available:
- `myapp-1.0.0.zip` - Full source code
- `myapp_1.0.0_all.deb` - Ubuntu/Debian package
- `myapp-1.0.0-1.fc37.noarch.rpm` - Fedora/RedHat package

---

## 🚀 Installation

### Quick Start (Recommended)

```bash
# 1. Make installer executable
chmod +x install-myapp.sh

# 2. Run smart installer
./install-myapp.sh

# 3. Reload terminal
exit

# 4. Use MyApp
myapp
```

### Step-by-Step Installation

#### Step 1: Check Dependencies

```bash
python3 -m myapp.dependencies
```

**Output should show:**
```
✅ Python версия 3.12 - OK
✅ pip установлен - OK
✅ setuptools установлен - OK
✅ Linux обнаружена - OK
```

#### Step 2: Install MyApp

**Method A: From .deb package (Ubuntu/Debian)**
```bash
sudo dpkg -i myapp_1.0.0_all.deb
```

**Method B: From source code**
```bash
cd myapp
sudo python3 setup.py install
```

**Method C: Using pip**
```bash
cd myapp
pip install -e .
```

#### Step 3: Verify Installation

```bash
which myapp
myapp --help
```

---

## 📖 Usage

```bash
# Display system info in default language
myapp

# Display in Russian
myapp ru

# Display in English
myapp en

# Show help
myapp --help
```

### Example Output

```
    ╔═══════════════════╗
    ║    MyApp Info     ║
    ╚═══════════════════╝

User..................... codespace@ubuntu
OS....................... Ubuntu 24.04.3 LTS
Kernel................... 6.8.0-1030-azure
CPU...................... Intel(R) Xeon(R) Platinum 8370C (2 cores)
RAM...................... 7.8Gi
Disk..................... 11G / 32G
Uptime................... 0d 0h 16m
Shell.................... bash
Time..................... 2025-12-07 21:39:28
```

---

## 🖥️ Supported Operating Systems

### Linux ✅ (Full Support)
- Ubuntu 20.04+
- Debian 10+
- Fedora 32+
- CentOS 8+
- Arch Linux
- And other Linux distributions

### macOS 🟡 (In Development)
- macOS 10.14+
- M1/M2/M3 compatible

### Windows 🟡 (In Development)
- Windows 10+ (via WSL 2)
- Recommended: WSL 2

---

## ⚠️ Troubleshooting

### Problem: "myapp: command not found"

**Solution:**
```bash
# Reload terminal
source ~/.bashrc  # or ~/.zshrc

# Or add to PATH manually
export PATH="$HOME/.local/bin:$PATH"

# Check installation
which myapp
```

### Problem: "Permission denied"

**Solution:**
```bash
# Use sudo
sudo python3 setup.py install

# Or install in user space
pip install --user -e .
```

### Problem: Python 3 not found

**Solution for Linux:**
```bash
sudo apt-get install python3 python3-pip
```

**Solution for macOS:**
```bash
brew install python3
```

---

## 📚 Documentation

| File | Description |
|------|-------------|
| README.md | Main documentation |
| QUICK_START.md | Quick start guide |
| OS_SUPPORT.md | OS-specific instructions |
| IMPROVEMENTS.md | Detailed improvements |
| INSTALL.md | Installation guide |

---

## 🔄 Update MyApp

```bash
# Update from source
git pull origin main

# Reinstall
pip install --upgrade -e .

# Or using deb package
sudo dpkg -i myapp_1.0.0_all.deb
```

---

## ❌ Uninstall

```bash
# If installed from .deb
sudo apt remove myapp

# If installed from pip
pip uninstall myapp

# If installed from source
sudo pip uninstall myapp
```

---

---

# Русский

# MyApp - Руководство по скачиванию и установке

## 📥 Как скачать MyApp

### Вариант 1: Скачать с GitHub (Рекомендуется)

```bash
# Клонировать репозиторий
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Или скачать как ZIP
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main
```

### Вариант 2: Скачать готовый пакет

**Для Ubuntu/Debian:**
```bash
# Скачать .deb пакет
wget https://github.com/fgdgfdgfdgfd/myapps/releases/download/v1.0.0/myapp_1.0.0_all.deb

# Установить
sudo dpkg -i myapp_1.0.0_all.deb
```

### Вариант 3: Скачать с Release страницы

Посетите: https://github.com/fgdgfdgfdgfd/myapps/releases/v1.0.0

Доступные файлы:
- `myapp-1.0.0.zip` - Полный исходный код
- `myapp_1.0.0_all.deb` - Пакет для Ubuntu/Debian
- `myapp-1.0.0-1.fc37.noarch.rpm` - Пакет для Fedora/RedHat

---

## 🚀 Установка

### Быстрый старт (Рекомендуется)

```bash
# 1. Сделать установщик исполняемым
chmod +x install-myapp.sh

# 2. Запустить умный установщик
./install-myapp.sh

# 3. Перезагрузить терминал
exit

# 4. Использовать MyApp
myapp
```

### Пошаговая установка

#### Шаг 1: Проверить зависимости

```bash
python3 -m myapp.dependencies
```

**Вывод должен показать:**
```
✅ Python версия 3.12 - OK
✅ pip установлен - OK
✅ setuptools установлен - OK
✅ Linux обнаружена - OK
```

#### Шаг 2: Установить MyApp

**Способ A: Из .deb пакета (Ubuntu/Debian)**
```bash
sudo dpkg -i myapp_1.0.0_all.deb
```

**Способ B: Из исходного кода**
```bash
cd myapp
sudo python3 setup.py install
```

**Способ C: Используя pip**
```bash
cd myapp
pip install -e .
```

#### Шаг 3: Проверить установку

```bash
which myapp
myapp --help
```

---

## 📖 Использование

```bash
# Показать информацию на языке системы
myapp

# Показать на русском
myapp ru

# Показать на английском
myapp en

# Показать справку
myapp --help
```

### Пример вывода

```
    ╔═══════════════════╗
    ║      MyApp Info    ║
    ╚═══════════════════╝

Пользователь........ codespace@ubuntu
ОС.................. Ubuntu 24.04.3 LTS
Ядро................ 6.8.0-1030-azure
Процессор........... Intel(R) Xeon(R) Platinum 8370C (2 ядер)
Память.............. 7.8Gi
Диск................ 11G / 32G
Uptime.............. 0d 0h 16m
Shell............... bash
Время............... 2025-12-07 21:39:28
```

---

## 🖥️ Поддерживаемые операционные системы

### Linux ✅ (Полная поддержка)
- Ubuntu 20.04+
- Debian 10+
- Fedora 32+
- CentOS 8+
- Arch Linux
- И другие дистрибутивы Linux

### macOS 🟡 (В разработке)
- macOS 10.14+
- Совместима с M1/M2/M3

### Windows 🟡 (В разработке)
- Windows 10+ (через WSL 2)
- Рекомендуется: WSL 2

---

## ⚠️ Решение проблем

### Проблема: "myapp: команда не найдена"

**Решение:**
```bash
# Перезагрузить терминал
source ~/.bashrc  # или ~/.zshrc

# Или добавить в PATH вручную
export PATH="$HOME/.local/bin:$PATH"

# Проверить установку
which myapp
```

### Проблема: "Permission denied"

**Решение:**
```bash
# Использовать sudo
sudo python3 setup.py install

# Или установить в пользовательское пространство
pip install --user -e .
```

### Проблема: Python 3 не найден

**Решение для Linux:**
```bash
sudo apt-get install python3 python3-pip
```

**Решение для macOS:**
```bash
brew install python3
```

---

## 📚 Документация

| Файл | Описание |
|------|---------|
| README.md | Основная документация |
| QUICK_START.md | Краткое руководство |
| OS_SUPPORT.md | Инструкции для разных ОС |
| IMPROVEMENTS.md | Описание улучшений |
| INSTALL.md | Руководство установки |

---

## 🔄 Обновить MyApp

```bash
# Обновить из репозитория
git pull origin main

# Переустановить
pip install --upgrade -e .

# Или использовать deb пакет
sudo dpkg -i myapp_1.0.0_all.deb
```

---

## ❌ Удалить MyApp

```bash
# Если установлено из .deb
sudo apt remove myapp

# Если установлено из pip
pip uninstall myapp

# Если установлено из исходников
sudo pip uninstall myapp
```

---

**Version**: 1.0.0  
**Date**: 2025-12-07  
**License**: MIT  
**Status**: ✅ Ready to use
