# MyApp - Методы скачивания и установки / Download and Installation Methods

**English** | [Русский](#русский-1)

---

## English

# Complete Comparison of Download and Installation Methods

## 📊 Quick Comparison Table

| Method | Speed | Ease | Compatibility | Recommended |
|--------|-------|------|---------------|-------------|
| Git Clone | ⚡ Fast | ⭐⭐⭐ | All OS | ✅ Yes (Dev) |
| ZIP Download | ⚡ Fast | ⭐⭐⭐ | All OS | ✅ Yes |
| .deb Package | ⚡⚡ Fastest | ⭐⭐⭐⭐ | Ubuntu/Debian | ✅ Yes |
| Smart Installer | ⚡⚡ Fastest | ⭐⭐⭐⭐ | Linux/macOS | ✅ Yes |
| pip Install | ⚡ Fast | ⭐⭐⭐ | All OS | ✅ Yes |
| Manual Setup | 🐢 Slow | ⭐ Hard | All OS | ❌ No |

---

## 🔽 Method 1: Git Clone (For Developers)

### Advantages:
- ✅ Get latest code
- ✅ Easy to update (`git pull`)
- ✅ Can contribute back
- ✅ Works on all platforms

### Command:
```bash
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps
chmod +x install-myapp.sh
./install-myapp.sh
```

### When to use:
- You want latest development version
- You plan to contribute
- You want to study the code

---

## 📦 Method 2: ZIP Download (Easy for Everyone)

### Advantages:
- ✅ Simple, no Git needed
- ✅ Self-contained
- ✅ Works everywhere
- ✅ Download once, use always

### Command:
```bash
# Download
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main

# Install
chmod +x install-myapp.sh
./install-myapp.sh
```

### When to use:
- You don't have Git installed
- You want simplicity
- You want a specific version

---

## 🔧 Method 3: .deb Package (Ubuntu/Debian Only)

### Advantages:
- ✅ Fastest installation
- ✅ Automatic dependency resolution
- ✅ Easy uninstall
- ✅ System package manager integration

### Command:
```bash
# Download
wget https://releases.myapp.dev/myapp_1.0.0_all.deb

# Install
sudo dpkg -i myapp_1.0.0_all.deb

# Use
myapp
```

### When to use:
- You're on Ubuntu or Debian
- You want fastest setup
- You prefer system packages

---

## 🚀 Method 4: Smart Installer (Recommended)

### Advantages:
- ✅ Checks dependencies automatically
- ✅ Installs missing packages
- ✅ Adds to PATH automatically
- ✅ Works on Linux and macOS
- ✅ Shows helpful messages

### Command:
```bash
# Download (using method 1 or 2)
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Run installer
chmod +x install-myapp.sh
./install-myapp.sh

# Ready!
myapp
```

### What it does:
1. Detects your OS
2. Checks Python version
3. Checks pip and setuptools
4. Installs missing dependencies
5. Installs MyApp
6. Adds to PATH
7. Tests installation

### When to use:
- **ALWAYS recommended** (unless using .deb)
- First time installation
- Want hassle-free setup

---

## 📥 Method 5: pip Install (For Advanced Users)

### Advantages:
- ✅ Works on all platforms
- ✅ Easy to update
- ✅ Integrates with Python ecosystem
- ✅ Can uninstall cleanly

### Command:
```bash
# Clone or download first
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps/myapp

# Install with pip
pip install -e .

# Add to PATH if needed
export PATH="$HOME/.local/bin:$PATH"

# Use
myapp
```

### When to use:
- You're familiar with pip
- You want Python package management
- You're on Windows or macOS

---

## 🎯 Step-by-Step for Beginners

### Step 1: Choose Download Method

**I recommend ZIP for beginners:**
```bash
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main
```

### Step 2: Check Dependencies

```bash
python3 -m myapp.dependencies
```

Should show all ✅ marks.

### Step 3: Run Installer

```bash
chmod +x install-myapp.sh
./install-myapp.sh
```

Just press Enter when asked questions.

### Step 4: Restart Terminal

```bash
exit
```

Then open a new terminal.

### Step 5: Use MyApp

```bash
myapp
myapp ru
myapp en
```

---

## 🔄 Migration Between Methods

### If you used method 1 (Git), want to try method 2 (ZIP):
```bash
# Just download the ZIP
# Delete the cloned folder
rm -rf myapps

# Extract ZIP and use new one
```

### If you need to switch installation methods:
```bash
# Uninstall current
pip uninstall myapp
# or
sudo apt remove myapp

# Install using new method
./install-myapp.sh
```

---

---

# Русский

# Полное сравнение методов скачивания и установки

## 📊 Таблица быстрого сравнения

| Метод | Скорость | Простота | Совместимость | Рекомендуется |
|--------|----------|----------|---------------|--------------|
| Git Clone | ⚡ Быстро | ⭐⭐⭐ | Все ОС | ✅ Да (Разработка) |
| ZIP Скачать | ⚡ Быстро | ⭐⭐⭐ | Все ОС | ✅ Да |
| .deb Пакет | ⚡⚡ Очень быстро | ⭐⭐⭐⭐ | Ubuntu/Debian | ✅ Да |
| Умный установщик | ⚡⚡ Очень быстро | ⭐⭐⭐⭐ | Linux/macOS | ✅ Да |
| pip Установка | ⚡ Быстро | ⭐⭐⭐ | Все ОС | ✅ Да |
| Ручная установка | 🐢 Медленно | ⭐ Сложно | Все ОС | ❌ Нет |

---

## 🔽 Метод 1: Git Clone (Для разработчиков)

### Преимущества:
- ✅ Получить последний код
- ✅ Легко обновить (`git pull`)
- ✅ Можно внести свой вклад
- ✅ Работает на всех платформах

### Команда:
```bash
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps
chmod +x install-myapp.sh
./install-myapp.sh
```

### Когда использовать:
- Нужна последняя версия
- Планируете внести вклад
- Хотите изучить код

---

## 📦 Метод 2: ZIP Скачивание (Просто для всех)

### Преимущества:
- ✅ Просто, Git не нужен
- ✅ Самодостаточный
- ✅ Работает везде
- ✅ Скачай один раз, используй всегда

### Команда:
```bash
# Скачать
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main

# Установить
chmod +x install-myapp.sh
./install-myapp.sh
```

### Когда использовать:
- Git не установлен
- Нужна простота
- Нужна конкретная версия

---

## 🔧 Метод 3: .deb Пакет (Только Ubuntu/Debian)

### Преимущества:
- ✅ Самая быстрая установка
- ✅ Автоматическое разрешение зависимостей
- ✅ Легко удалить
- ✅ Интеграция с системным пакетным менеджером

### Команда:
```bash
# Скачать
wget https://releases.myapp.dev/myapp_1.0.0_all.deb

# Установить
sudo dpkg -i myapp_1.0.0_all.deb

# Использовать
myapp
```

### Когда использовать:
- Вы на Ubuntu или Debian
- Нужна самая быстрая установка
- Предпочитаете системные пакеты

---

## 🚀 Метод 4: Умный установщик (Рекомендуется)

### Преимущества:
- ✅ Автоматическая проверка зависимостей
- ✅ Установка недостающих пакетов
- ✅ Автоматическое добавление в PATH
- ✅ Работает на Linux и macOS
- ✅ Полезные сообщения

### Команда:
```bash
# Скачать (метод 1 или 2)
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps

# Запустить установщик
chmod +x install-myapp.sh
./install-myapp.sh

# Готово!
myapp
```

### Что он делает:
1. Определяет вашу ОС
2. Проверяет версию Python
3. Проверяет pip и setuptools
4. Устанавливает недостающие пакеты
5. Устанавливает MyApp
6. Добавляет в PATH
7. Проверяет установку

### Когда использовать:
- **ВСЕГДА рекомендуется** (кроме .deb)
- Первая установка
- Хотите простую установку

---

## 📥 Метод 5: pip Установка (Для продвинутых)

### Преимущества:
- ✅ Работает на всех платформах
- ✅ Легко обновить
- ✅ Интеграция с Python
- ✅ Чистое удаление

### Команда:
```bash
# Клонировать или скачать
git clone https://github.com/fgdgfdgfdgfd/myapps.git
cd myapps/myapp

# Установить с pip
pip install -e .

# Добавить в PATH если нужно
export PATH="$HOME/.local/bin:$PATH"

# Использовать
myapp
```

### Когда использовать:
- Вы знаете pip
- Хотите управление пакетами Python
- Вы на Windows или macOS

---

## 🎯 Пошаговая инструкция для новичков

### Шаг 1: Выберите метод скачивания

**Рекомендую ZIP для начинающих:**
```bash
wget https://github.com/fgdgfdgfdgfd/myapps/archive/refs/heads/main.zip
unzip main.zip
cd myapps-main
```

### Шаг 2: Проверьте зависимости

```bash
python3 -m myapp.dependencies
```

Все должны показать ✅ метки.

### Шаг 3: Запустите установщик

```bash
chmod +x install-myapp.sh
./install-myapp.sh
```

Просто нажимайте Enter на вопросы.

### Шаг 4: Перезагрузите терминал

```bash
exit
```

Откройте новый терминал.

### Шаг 5: Используйте MyApp

```bash
myapp
myapp ru
myapp en
```

---

## 🔄 Переход между методами

### Если использовали метод 1 (Git), хотите метод 2 (ZIP):
```bash
# Просто скачайте ZIP
# Удалите клонированную папку
rm -rf myapps

# Извлеките ZIP и используйте новую
```

### Если нужно переключиться на другой способ установки:
```bash
# Удалить текущую
pip uninstall myapp
# или
sudo apt remove myapp

# Установить новым методом
./install-myapp.sh
```

---

**Версия**: 1.0.0  
**Дата**: 2025-12-07  
**Лицензия**: MIT  
**Статус**: ✅ Готово к использованию
