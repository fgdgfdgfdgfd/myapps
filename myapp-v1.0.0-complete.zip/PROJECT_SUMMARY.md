## 📦 MyApp Project Summary

**Version**: 1.0.0  
**Language**: Python 3  
**Package Format**: Debian (.deb)  
**Archive Size**: 22 KB  

---

## 📋 Package Contents

```
myapp-1.0.0.zip (22 KB)
├── myapp/                          # Source code directory
│   ├── myapp/
│   │   ├── __init__.py             # Package initialization
│   │   └── main.py                 # Main application (6.7 KB)
│   ├── debian/                     # Debian packaging files
│   │   ├── control                 # Package metadata
│   │   ├── rules                   # Build rules
│   │   ├── changelog               # Version history
│   │   ├── copyright               # MIT License
│   │   ├── compat                  # Debhelper v12
│   │   └── source/format           # Debian format (native)
│   ├── setup.py                    # Python setup configuration
│   └── README.md                   # Russian/English docs
├── README.md                       # Main documentation (bilingual)
├── INSTALL.md                      # Installation guide (bilingual)
├── build-and-install.sh            # Automated build script
└── myapp_1.0.0_all.deb (8 KB)     # Pre-built Debian package
```

---

## 🚀 Quick Start

### Option 1: Direct Package Installation
```bash
sudo dpkg -i myapp_1.0.0_all.deb
```

### Option 2: Automated Build & Install
```bash
unzip myapp-1.0.0.zip
cd myapp-1.0.0
chmod +x build-and-install.sh
./build-and-install.sh
```

### Option 3: From Source
```bash
unzip myapp-1.0.0.zip
cd myapp-1.0.0/myapp
sudo python3 setup.py install
```

---

## 📝 Features

✅ System information display (OS, kernel, CPU, RAM, disk, uptime)  
✅ Bilingual interface (English & Russian)  
✅ Multiple usage modes:
   - `myapp` - System language (default English)
   - `myapp ru` - Russian output
   - `myapp en` - English output
   - `myapp --help` - Show help

✅ Debian package (.deb) for easy installation  
✅ Can be installed via `sudo dpkg -i`  
✅ Provides `/usr/bin/myapp` command  

---

## 🔧 System Requirements

- **OS**: Linux (Ubuntu 18.04+, Debian 10+, etc.)
- **Python**: 3.6+
- **Package Manager**: apt/dpkg
- **Dependencies**: Standard Linux utilities (grep, free, df)

---

## 📚 Documentation Files

| File | Purpose | Languages |
|------|---------|-----------|
| `README.md` | Main documentation | EN / RU |
| `INSTALL.md` | Installation guide | EN / RU |
| `build-and-install.sh` | Automated setup script | Bash |
| `myapp/README.md` | Package documentation | EN / RU |
| `myapp/debian/copyright` | License info | English |

---

## 🎯 Usage Examples

```bash
# Display system info (auto-detect language)
myapp

# Display in Russian
myapp ru

# Display in English
myapp en

# Show command help
myapp --help

# Verify installation
which myapp
```

**Example Output** (Russian):
```
    ╔═══════════════════╗
    ║    MyApp Info     ║
    ╚═══════════════════╝

Пользователь........ user@ubuntu
ОС.................. Ubuntu 24.04.3 LTS
Ядро................ 6.8.0-1012-generic
Процессор........... Intel(R) Core(TM) i7 (8 ядер)
Память.............. 16Gi
Диск................ 50G / 100G
Uptime.............. 5d 3h 42m
Shell............... bash
Время............... 2025-12-07 14:23:15
```

---

## 📦 Package Details

```
Package: myapp
Version: 1.0.0
Architecture: all (platform independent)
Size: 7.8 KB (compressed)
Depends: python3 (>= 3.6)
Maintainer: MyApp Team <team@myapp.dev>
License: MIT
```

---

## 🔄 Update Instructions

To update MyApp:

```bash
# Remove old version
sudo dpkg -r myapp

# Install new version
sudo dpkg -i myapp_1.0.0_all.deb
```

---

## 🛠️ Build Information

**Built with**:
- Python 3.12
- Debhelper 13
- Debian format: native (3.0)

**Build Date**: 2025-12-07  
**Build Commands**:
```bash
dpkg-buildpackage -us -uc
```

---

## 📝 License

MIT License - See `myapp/debian/copyright` for full text.

All files in this package are licensed under MIT.

---

## 💡 Tips

1. **For Development**: Use `pip install -e .` for editable mode
2. **For Distribution**: Share the `.deb` file or this zip archive
3. **For Enterprise**: Modify debian/control for corporate requirements
4. **For Customization**: Edit `myapp/myapp/main.py` to add features

---

## 📞 Support

For issues or questions:
- Check `INSTALL.md` for troubleshooting
- Review `README.md` for feature documentation
- Run `myapp --help` for command options

---

**Happy coding!** 🎉
