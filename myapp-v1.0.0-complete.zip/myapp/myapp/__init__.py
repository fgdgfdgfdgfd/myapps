"""MyApp - системная информация в стиле neofetch"""

__version__ = "1.0.0"
__author__ = "MyApp Team"
