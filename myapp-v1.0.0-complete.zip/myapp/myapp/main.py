#!/usr/bin/env python3
"""
MyApp - утилита для отображения информации о системе
Аналог neofetch на Python
"""

import os
import platform
import subprocess
import socket
from pathlib import Path
from datetime import datetime
import sys


# Текстовые строки на двух языках
MESSAGES = {
    'ru': {
        'title': 'MyApp Info',
        'user': 'Пользователь',
        'os': 'ОС',
        'kernel': 'Ядро',
        'cpu': 'Процессор',
        'ram': 'Память',
        'disk': 'Диск',
        'uptime': 'Uptime',
        'shell': 'Shell',
        'time': 'Время',
        'cores': 'ядер',
    },
    'en': {
        'title': 'MyApp Info',
        'user': 'User',
        'os': 'OS',
        'kernel': 'Kernel',
        'cpu': 'CPU',
        'ram': 'RAM',
        'disk': 'Disk',
        'uptime': 'Uptime',
        'shell': 'Shell',
        'time': 'Time',
        'cores': 'cores',
    }
}


def get_language():
    """Определить язык из переменной окружения или аргументов"""
    # Проверить аргументы команды
    if len(sys.argv) > 1:
        lang = sys.argv[1].lower()
        if lang in MESSAGES:
            return lang
    
    # Проверить переменную окружения LANG
    lang_env = os.environ.get('LANG', '').lower()
    if 'ru' in lang_env or 'ru_ru' in lang_env:
        return 'ru'
    
    # По умолчанию английский
    return 'en'


class SystemInfo:
    """Класс для сбора информации о системе"""
    
    @staticmethod
    def get_os_info():
        """Получить информацию об ОС"""
        return platform.system()
    
    @staticmethod
    def get_distro_info():
        """Получить информацию о дистрибутиве"""
        try:
            with open('/etc/os-release', 'r') as f:
                for line in f:
                    if line.startswith('PRETTY_NAME'):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
        return "Unknown"
    
    @staticmethod
    def get_kernel():
        """Получить версию ядра"""
        return platform.release()
    
    @staticmethod
    def get_hostname():
        """Получить имя хоста"""
        return socket.gethostname()
    
    @staticmethod
    def get_cpu_count():
        """Получить количество ядер процессора"""
        return os.cpu_count() or 1
    
    @staticmethod
    def get_cpu_model():
        """Получить модель процессора"""
        try:
            result = subprocess.run(['grep', '-m1', 'model name', '/proc/cpuinfo'],
                                  capture_output=True, text=True)
            if result.stdout:
                return result.stdout.split(':')[1].strip()
        except:
            pass
        return "Unknown"
    
    @staticmethod
    def get_ram():
        """Получить информацию об оперативной памяти"""
        try:
            result = subprocess.run(['free', '-h'], capture_output=True, text=True)
            lines = result.stdout.split('\n')
            if len(lines) > 1:
                parts = lines[1].split()
                return f"{parts[1]}"
        except:
            pass
        return "Unknown"
    
    @staticmethod
    def get_disk_usage():
        """Получить использование диска"""
        try:
            result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True)
            lines = result.stdout.split('\n')
            if len(lines) > 1:
                parts = lines[1].split()
                return f"{parts[2]} / {parts[1]}"
        except:
            pass
        return "Unknown"
    
    @staticmethod
    def get_uptime():
        """Получить время работы системы"""
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = int(float(f.read().split()[0]))
                days = uptime_seconds // 86400
                hours = (uptime_seconds % 86400) // 3600
                minutes = (uptime_seconds % 3600) // 60
                return f"{days}d {hours}h {minutes}m"
        except:
            pass
        return "Unknown"
    
    @staticmethod
    def get_shell():
        """Получить текущий shell"""
        return os.environ.get('SHELL', 'Unknown').split('/')[-1]
    
    @staticmethod
    def get_user():
        """Получить текущего пользователя"""
        return os.environ.get('USER', 'Unknown')


def print_info(lang='en'):
    """Вывести информацию о системе"""
    
    messages = MESSAGES[lang]
    
    # ASCII art логотип
    logo = f"""
    ╔═══════════════════╗
    ║   {messages['title']:^17}║
    ╚═══════════════════╝
    """
    
    print(logo)
    
    # Собираем информацию
    info = SystemInfo()
    
    cpu_info = f"{info.get_cpu_model()} ({info.get_cpu_count()} {messages['cores']})"
    
    data = [
        (messages['user'], f"{info.get_user()}@{info.get_hostname()}"),
        (messages['os'], info.get_distro_info()),
        (messages['kernel'], info.get_kernel()),
        (messages['cpu'], cpu_info),
        (messages['ram'], info.get_ram()),
        (messages['disk'], info.get_disk_usage()),
        (messages['uptime'], info.get_uptime()),
        (messages['shell'], info.get_shell()),
        (messages['time'], datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    
    # Выводим информацию
    for key, value in data:
        print(f"{key:.<20} {value}")
    
    print()


def main():
    """Главная функция"""
    lang = get_language()
    
    # Показать справку
    if len(sys.argv) > 1 and sys.argv[1] in ['--help', '-h', 'help']:
        print("MyApp - System Information Utility")
        print("Утилита информации о системе")
        print()
        print("Usage / Использование:")
        print("  myapp              - Show info in system language (English by default)")
        print("  myapp ru           - Показать информацию на русском")
        print("  myapp en           - Show information in English")
        print("  myapp --help       - Show this help")
        print()
        return
    
    print_info(lang)


if __name__ == "__main__":
    main()
