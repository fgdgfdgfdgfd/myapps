#!/usr/bin/env python3
"""
Модуль для проверки зависимостей перед установкой
"""

import sys
import subprocess
import platform


def check_python_version():
    """Проверить версию Python"""
    required_version = (3, 6)
    current_version = sys.version_info[:2]
    
    if current_version < required_version:
        print(f"❌ ОШИБКА: Python {required_version[0]}.{required_version[1]}+ требуется")
        print(f"   У вас установлена версия {current_version[0]}.{current_version[1]}")
        return False
    
    print(f"✅ Python версия {current_version[0]}.{current_version[1]} - OK")
    return True


def check_pip():
    """Проверить наличие pip"""
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      capture_output=True, check=True)
        print("✅ pip установлен - OK")
        return True
    except:
        print("❌ ОШИБКА: pip не установлен")
        print("   Установите pip командой: sudo apt-get install python3-pip")
        return False


def check_setuptools():
    """Проверить наличие setuptools"""
    try:
        import setuptools
        print("✅ setuptools установлен - OK")
        return True
    except ImportError:
        print("❌ ОШИБКА: setuptools не установлен")
        print("   Установите: pip install setuptools")
        return False


def check_os_compatibility():
    """Проверить совместимость ОС"""
    system = platform.system()
    
    if system == "Linux":
        print("✅ Linux обнаружена - OK")
        return True
    elif system == "Darwin":
        print("⚠️  macOS обнаружена - поддержка в развитии")
        return True
    elif system == "Windows":
        print("⚠️  Windows обнаружена - поддержка в развитии")
        return True
    else:
        print(f"❌ ОШИБКА: ОС {system} не поддерживается")
        return False


def check_all_dependencies():
    """Проверить все зависимости"""
    print("\n" + "="*50)
    print("📋 Проверка зависимостей для MyApp")
    print("="*50 + "\n")
    
    checks = [
        check_python_version(),
        check_pip(),
        check_setuptools(),
        check_os_compatibility(),
    ]
    
    print("\n" + "="*50)
    if all(checks):
        print("✅ ВСЕ ЗАВИСИМОСТИ УДОВЛЕТВОРЕНЫ!")
        print("Можете продолжить установку.")
    else:
        print("❌ НЕ ВСЕ ЗАВИСИМОСТИ УДОВЛЕТВОРЕНЫ!")
        print("Пожалуйста, установите отсутствующие зависимости.")
        sys.exit(1)
    print("="*50 + "\n")


if __name__ == "__main__":
    check_all_dependencies()
