#!/usr/bin/env python3
"""
Модуль для автоматического добавления myapp в PATH
"""

import os
import sys
import subprocess
from pathlib import Path


def get_shell_config_file():
    """Определить файл конфигурации shell"""
    shell = os.environ.get('SHELL', '/bin/bash')
    
    if 'bash' in shell:
        return Path.home() / '.bashrc'
    elif 'zsh' in shell:
        return Path.home() / '.zshrc'
    elif 'fish' in shell:
        return Path.home() / '.config/fish/config.fish'
    else:
        return Path.home() / '.bashrc'  # По умолчанию


def get_install_path():
    """Получить путь установки myapp"""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "site", "--user-scripts"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except:
        return os.path.expanduser("~/.local/bin")


def add_to_path():
    """Добавить путь установки в PATH"""
    install_path = get_install_path()
    config_file = get_shell_config_file()
    
    # Проверить, добавлен ли уже в PATH
    if "myapp" in os.environ.get('PATH', ''):
        print(f"✅ myapp уже в PATH: {install_path}")
        return True
    
    # Проверить, есть ли уже в конфиге
    try:
        with open(config_file, 'r') as f:
            content = f.read()
            if install_path in content:
                print(f"✅ Путь {install_path} уже в {config_file.name}")
                return True
    except:
        pass
    
    # Добавить в конфиг
    path_export = f'\nexport PATH="{install_path}:$PATH"  # Added by MyApp installer\n'
    
    try:
        with open(config_file, 'a') as f:
            f.write(path_export)
        
        print(f"✅ Добавлено в {config_file.name}:")
        print(f'   export PATH="{install_path}:$PATH"')
        print(f"\n⚠️  ВАЖНО: Перезагрузите терминал или выполните:")
        print(f'   source {config_file}')
        return True
    except Exception as e:
        print(f"❌ ОШИБКА при добавлении в PATH: {e}")
        print(f"   Вручную добавьте в {config_file}:")
        print(f'   export PATH="{install_path}:$PATH"')
        return False


if __name__ == "__main__":
    print("Добавление myapp в PATH...\n")
    add_to_path()
