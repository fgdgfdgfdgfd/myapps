#!/usr/bin/env python3

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="myapp",
    version="1.0.0",
    author="MyApp Team",
    description="Утилита для отображения информации о системе (аналог neofetch)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Linux",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "myapp=myapp.main:main",
        ],
    },
)
