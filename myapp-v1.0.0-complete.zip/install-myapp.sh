#!/bin/bash
# Скрипт установки MyApp с проверкой зависимостей для Linux и macOS

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  MyApp - System Information Utility${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Определить ОС
OS_TYPE=$(uname -s)

echo -e "${YELLOW}Обнаруженная ОС: $OS_TYPE${NC}\n"

# Проверка зависимостей для Linux
if [[ "$OS_TYPE" == "Linux" ]]; then
    echo -e "${YELLOW}📋 Проверка зависимостей для Linux...${NC}\n"
    
    # Проверить Python 3
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}❌ Python 3 не установлен${NC}"
        echo -e "${YELLOW}Установка Python 3...${NC}"
        sudo apt-get update
        sudo apt-get install -y python3 python3-pip python3-setuptools
    else
        echo -e "${GREEN}✅ Python 3 установлен${NC}"
    fi
    
    # Проверить pip
    if ! command -v pip3 &> /dev/null; then
        echo -e "${RED}❌ pip3 не установлен${NC}"
        echo -e "${YELLOW}Установка pip3...${NC}"
        sudo apt-get install -y python3-pip
    else
        echo -e "${GREEN}✅ pip3 установлен${NC}"
    fi

# Проверка зависимостей для macOS
elif [[ "$OS_TYPE" == "Darwin" ]]; then
    echo -e "${YELLOW}📋 Проверка зависимостей для macOS...${NC}\n"
    
    # Проверить Python 3
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}❌ Python 3 не установлен${NC}"
        echo -e "${YELLOW}Установка Python 3 через Homebrew...${NC}"
        
        # Проверить Homebrew
        if ! command -v brew &> /dev/null; then
            echo -e "${YELLOW}Установка Homebrew...${NC}"
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        fi
        
        brew install python3
    else
        echo -e "${GREEN}✅ Python 3 установлен${NC}"
    fi
    
    # Проверить pip
    if ! command -v pip3 &> /dev/null; then
        echo -e "${RED}❌ pip3 не установлен${NC}"
        echo -e "${YELLOW}Установка pip3...${NC}"
        python3 -m ensurepip --upgrade
    else
        echo -e "${GREEN}✅ pip3 установлен${NC}"
    fi

else
    echo -e "${RED}❌ Неподдерживаемая ОС: $OS_TYPE${NC}"
    echo -e "${YELLOW}Поддерживаемые ОС: Linux, macOS${NC}"
    echo -e "${YELLOW}Для Windows используйте WSL или установите вручную.${NC}"
    exit 1
fi

echo ""

# Проверить setuptools
echo -e "${YELLOW}Проверка setuptools...${NC}"
pip3 install --upgrade setuptools

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Установка MyApp${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Перейти в директорию myapp
cd "$(dirname "$0")/myapp" || exit 1

# Установить MyApp
echo -e "${YELLOW}Установка MyApp...${NC}"
sudo python3 setup.py install

echo ""
echo -e "${GREEN}✅ MyApp успешно установлена!${NC}\n"

# Добавить в PATH для macOS
if [[ "$OS_TYPE" == "Darwin" ]]; then
    INSTALL_PATH=$(python3 -m site --user-scripts)
    
    if [[ ! ":$PATH:" == *":$INSTALL_PATH:"* ]]; then
        echo -e "${YELLOW}Добавление $INSTALL_PATH в PATH...${NC}"
        
        if [[ -f "$HOME/.zprofile" ]]; then
            echo "export PATH=\"$INSTALL_PATH:\$PATH\"" >> "$HOME/.zprofile"
            echo -e "${GREEN}✅ Добавлено в ~/.zprofile${NC}"
        fi
        
        if [[ -f "$HOME/.bash_profile" ]]; then
            echo "export PATH=\"$INSTALL_PATH:\$PATH\"" >> "$HOME/.bash_profile"
            echo -e "${GREEN}✅ Добавлено в ~/.bash_profile${NC}"
        fi
    fi
fi

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}  🎉 Установка завершена!${NC}"
echo -e "${BLUE}========================================${NC}\n"

echo -e "${YELLOW}Используйте команды:${NC}"
echo -e "  ${BLUE}myapp${NC}      - Показать информацию"
echo -e "  ${BLUE}myapp ru${NC}   - На русском языке"
echo -e "  ${BLUE}myapp en${NC}   - На английском языке"
echo -e "  ${BLUE}myapp --help${NC} - Справка"
echo ""

# Проверить установку
if command -v myapp &> /dev/null; then
    echo -e "${GREEN}✅ MyApp готова к использованию!${NC}\n"
    echo "Демонстрация:"
    myapp
else
    echo -e "${YELLOW}⚠️  Перезагрузите терминал и используйте команду 'myapp'${NC}\n"
fi
