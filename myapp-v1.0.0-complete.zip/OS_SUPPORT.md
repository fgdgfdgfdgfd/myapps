# MyApp - Поддержка различных операционных систем

## 🖥️ Поддерживаемые ОС

### ✅ Linux (полная поддержка)
- Ubuntu 20.04+
- Debian 10+
- Fedora 32+
- CentOS 8+
- Arch Linux

### 🟡 macOS (в разработке)
- macOS 10.14+
- M1/M2/M3 совместимость

### 🟡 Windows (в разработке)
- Windows 10+
- WSL 2 (рекомендуется)

---

## 🚀 Установка на разных ОС

### Linux

#### Способ 1: Из .deb пакета (Ubuntu/Debian)
```bash
sudo dpkg -i myapp_1.0.0_all.deb
```

#### Способ 2: С автоматической проверкой зависимостей
```bash
chmod +x install-myapp.sh
./install-myapp.sh
```

#### Способ 3: Из исходного кода
```bash
cd myapp
sudo python3 setup.py install
```

#### Способ 4: Через pip
```bash
cd myapp
pip install -e .
```

---

### macOS

#### Способ 1: С автоматической проверкой зависимостей
```bash
chmod +x install-myapp.sh
./install-myapp.sh
```

Скрипт автоматически:
- Проверит наличие Homebrew (установит, если нужно)
- Установит Python 3 (если не установлен)
- Установит все необходимые зависимости
- Добавит MyApp в PATH

#### Способ 2: Вручную через Homebrew
```bash
# Установить Python 3
brew install python3

# Установить MyApp
cd myapp
pip3 install -e .
```

#### Способ 3: Вручную через pip
```bash
# Убедитесь, что установлен Python 3.6+
python3 --version

# Установите MyApp
cd myapp
pip3 install -e .
```

---

### Windows

#### Способ 1: WSL 2 (рекомендуется)
WSL 2 позволяет запускать Linux прямо на Windows:

```bash
# В WSL 2 терминале
chmod +x install-myapp.sh
./install-myapp.sh
```

#### Способ 2: Вручную (требуется Python 3)
1. Установите [Python 3](https://www.python.org/downloads/)
2. Откройте Command Prompt или PowerShell
3. Перейдите в папку проекта:
   ```cmd
   cd myapp
   pip install -e .
   ```

#### Способ 3: Через Git Bash
```bash
cd myapp
pip3 install -e .
```

---

## ✅ Проверка установки

После установки проверьте, что MyApp работает:

```bash
myapp --help
```

Вы должны увидеть справку с доступными командами.

---

## 🔍 Проверка зависимостей

Чтобы проверить, все ли зависимости установлены:

```bash
# Linux
python3 -m myapp.dependencies

# macOS
python3 -m myapp.dependencies

# Windows (Python Command Line)
python -m myapp.dependencies
```

---

## 🐛 Решение проблем

### Проблема: "myapp: команда не найдена"

**Решение:**
1. Убедитесь, что MyApp установлена:
   ```bash
   pip list | grep myapp
   ```

2. Добавьте путь в PATH вручную:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```

3. Перезагрузите терминал

### Проблема: "Permission denied" при установке

**Решение:**
```bash
# Используйте sudo для установки
sudo python3 setup.py install

# ИЛИ установите без sudo в user-space
pip install --user -e .
```

### Проблема: Python 3 не найден

**Решение для Linux:**
```bash
sudo apt-get install python3 python3-pip
```

**Решение для macOS:**
```bash
brew install python3
```

**Решение для Windows:**
Скачайте с [python.org](https://www.python.org/downloads/)

### Проблема: No module named setuptools

**Решение:**
```bash
pip install --upgrade setuptools
```

---

## 📊 Таблица совместимости

| ОС | Python | Status | Тестировано |
|---|---|---|---|
| Ubuntu 20.04+ | 3.6+ | ✅ Полная | 24.04.3 LTS |
| Debian 10+ | 3.6+ | ✅ Полная | - |
| Fedora 32+ | 3.6+ | ✅ Полная | - |
| CentOS 8+ | 3.6+ | ✅ Полная | - |
| macOS 10.14+ | 3.6+ | 🟡 Разработка | - |
| Windows 10 (WSL2) | 3.6+ | 🟡 Разработка | - |
| Windows 10 (Native) | 3.9+ | 🟡 Разработка | - |

---

## 🤝 Помощь и поддержка

Если у вас есть проблемы:
1. Проверьте версию Python: `python3 --version`
2. Проверьте установку: `pip list | grep myapp`
3. Смотрите логи установки
4. Создайте issue на GitHub

---

## 📝 История изменений

### v1.0.0 (2025-12-07)
- ✅ Поддержка Linux (полная)
- 🟡 Поддержка macOS (в разработке)
- 🟡 Поддержка Windows (в разработке)
- ✅ Проверка зависимостей
- ✅ Автоматическое добавление в PATH
