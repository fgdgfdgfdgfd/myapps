# Installation Guide / Руководство по установке

**English** | [Русский](#русский-1)

## English

### Quick Installation

There are several ways to install MyApp:

#### Method 1: Direct .deb Installation (Simplest)

```bash
# If you have the .deb file
sudo dpkg -i myapp_1.0.0_all.deb

# Then use the command
myapp
```

#### Method 2: Build and Install Script

```bash
# Extract the archive
unzip myapp-1.0.0.zip
cd myapp-1.0.0

# Make script executable and run it
chmod +x build-and-install.sh
./build-and-install.sh
```

#### Method 3: Manual Build

```bash
cd myapp

# Install dependencies (if not already installed)
sudo apt-get update
sudo apt-get install -y debhelper python3-all python3-setuptools dh-python fakeroot

# Build the package
dpkg-buildpackage -us -uc

# Install
sudo dpkg -i ../myapp_1.0.0_all.deb
```

#### Method 4: From Source with pip

```bash
cd myapp

# Install in development mode
pip install -e .

# Or install for all users
sudo pip install .

# Then use
myapp
```

### Verify Installation

```bash
# Check if myapp is installed
which myapp

# Display system information
myapp

# Show help
myapp --help

# Display in Russian
myapp ru

# Display in English
myapp en
```

### Uninstall

```bash
# Method 1: Using apt
sudo apt remove myapp

# Method 2: Using dpkg
sudo dpkg -r myapp

# Method 3: Complete removal with configuration
sudo apt purge myapp
```

### Troubleshooting

**Problem**: "myapp: command not found"
```bash
# Solution 1: Install from package
sudo dpkg -i myapp_1.0.0_all.deb

# Solution 2: Reinstall pip package
pip install --upgrade --force-reinstall myapp
```

**Problem**: Permission denied when using build-and-install.sh
```bash
# Solution: Make script executable
chmod +x build-and-install.sh
```

**Problem**: Missing dependencies
```bash
# Install required packages
sudo apt-get install -y python3 python3-pip debhelper python3-setuptools
```

---

# Русский

### Быстрая установка

Есть несколько способов установить MyApp:

#### Способ 1: Прямая установка .deb (самый простой)

```bash
# Если у вас есть файл .deb
sudo dpkg -i myapp_1.0.0_all.deb

# Затем используйте команду
myapp
```

#### Способ 2: Скрипт сборки и установки

```bash
# Распакуйте архив
unzip myapp-1.0.0.zip
cd myapp-1.0.0

# Сделайте скрипт исполняемым и запустите
chmod +x build-and-install.sh
./build-and-install.sh
```

#### Способ 3: Ручная сборка

```bash
cd myapp

# Установите зависимости (если они ещё не установлены)
sudo apt-get update
sudo apt-get install -y debhelper python3-all python3-setuptools dh-python fakeroot

# Соберите пакет
dpkg-buildpackage -us -uc

# Установите
sudo dpkg -i ../myapp_1.0.0_all.deb
```

#### Способ 4: Из исходников с pip

```bash
cd myapp

# Установите в режиме разработки
pip install -e .

# Или установите для всех пользователей
sudo pip install .

# Затем используйте
myapp
```

### Проверка установки

```bash
# Проверьте, установлена ли myapp
which myapp

# Отобразить информацию о системе
myapp

# Показать справку
myapp --help

# Отобразить на русском
myapp ru

# Отобразить на английском
myapp en
```

### Удаление

```bash
# Способ 1: Через apt
sudo apt remove myapp

# Способ 2: Через dpkg
sudo dpkg -r myapp

# Способ 3: Полное удаление с конфигами
sudo apt purge myapp
```

### Устранение проблем

**Проблема**: "myapp: команда не найдена"
```bash
# Решение 1: Установите из пакета
sudo dpkg -i myapp_1.0.0_all.deb

# Решение 2: Переустановите pip пакет
pip install --upgrade --force-reinstall myapp
```

**Проблема**: Отказано в доступе при использовании build-and-install.sh
```bash
# Решение: Сделайте скрипт исполняемым
chmod +x build-and-install.sh
```

**Проблема**: Отсутствуют зависимости
```bash
# Установите требуемые пакеты
sudo apt-get install -y python3 python3-pip debhelper python3-setuptools
```
