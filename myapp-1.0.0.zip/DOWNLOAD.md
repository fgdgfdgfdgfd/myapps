# 📥 MyApp Download & Installation

## 📦 What You're Getting

**myapp-1.0.0.zip** (28 KB) - Complete package containing:

✅ **Pre-built .deb package** - Ready to install  
✅ **Full source code** - Bilingual (Russian & English)  
✅ **Build tools** - Automated installation script  
✅ **Complete documentation** - Installation guides for all platforms  

---

## 🚀 Installation Methods

### **Method 1: Fastest Setup (Recommended)**

```bash
# Extract the archive
unzip myapp-1.0.0.zip
cd myapp-1.0.0

# Run automated installer
chmod +x build-and-install.sh
./build-and-install.sh
```

✅ **Time**: 2-3 minutes  
✅ **Effort**: Minimal  
✅ **Best for**: Most users

---

### **Method 2: Direct Package Install**

```bash
# Extract archive
unzip myapp-1.0.0.zip
cd myapp-1.0.0

# Install the .deb file directly
sudo dpkg -i myapp_1.0.0_all.deb
```

✅ **Time**: 10 seconds  
✅ **Effort**: Very minimal  
✅ **Best for**: Quick installation

---

### **Method 3: Install from Source**

```bash
# Extract and navigate
unzip myapp-1.0.0.zip
cd myapp-1.0.0/myapp

# Install Python setup
sudo python3 setup.py install
```

✅ **Time**: 1-2 minutes  
✅ **Effort**: Easy  
✅ **Best for**: Development

---

## ✅ Verify Installation

After installation, test MyApp:

```bash
# Display in system language (English by default)
myapp

# Display in Russian
myapp ru

# Display in English  
myapp en

# Show help
myapp --help
```

**Expected Output:**
```
    ╔═══════════════════╗
    ║    MyApp Info     ║
    ╚═══════════════════╝

User................ username@computer
OS.................. Ubuntu 24.04.3 LTS
Kernel.............. 6.8.0-1030-azure
CPU................. Intel/AMD processor (cores)
RAM................. 16Gi
Disk................ 50G / 100G
Uptime.............. 5d 3h 42m
Shell............... bash
Time................ 2025-12-07 21:00:00
```

---

## �� Archive Contents

```
myapp-1.0.0.zip
├── myapp/                           # Source code
│   ├── myapp/
│   │   ├── __init__.py
│   │   └── main.py                 # Application code
│   ├── debian/                     # Debian packaging
│   │   └── [packaging files]
│   └── setup.py                    # Installation config
├── README.md                       # Full documentation (EN/RU)
├── INSTALL.md                      # Installation guide (EN/RU)
├── PROJECT_SUMMARY.md              # Project overview
├── build-and-install.sh            # Automated installer
└── myapp_1.0.0_all.deb            # Pre-built package
```

---

## 🔧 System Requirements

| Requirement | Version |
|------------|---------|
| **OS** | Ubuntu 18.04+, Debian 10+, or any Linux |
| **Python** | 3.6+ |
| **Package Manager** | apt/dpkg |
| **Disk Space** | ~50 MB |
| **RAM** | Minimal (utility only) |

---

## 🆘 Troubleshooting

### Problem: "Permission denied" on build-and-install.sh

```bash
chmod +x build-and-install.sh
./build-and-install.sh
```

### Problem: "myapp: command not found"

```bash
# Reinstall the package
sudo dpkg -r myapp
sudo dpkg -i myapp_1.0.0_all.deb
```

### Problem: Missing dependencies

```bash
# Install required packages
sudo apt-get update
sudo apt-get install -y python3 debhelper python3-setuptools
```

### Problem: Want to uninstall

```bash
sudo apt remove myapp
# or
sudo dpkg -r myapp
```

---

## 📚 Documentation

| File | Purpose |
|------|---------|
| **README.md** | Complete features and usage guide |
| **INSTALL.md** | Detailed installation instructions |
| **PROJECT_SUMMARY.md** | Project overview and details |
| **build-and-install.sh** | Automated setup |

All files are available in **English** and **Russian**.

---

## 🎯 Quick Reference

```bash
# Display system info (auto-language)
myapp

# Force language
myapp en    # English
myapp ru    # Russian

# Get help
myapp --help

# Uninstall
sudo apt remove myapp
```

---

## 💡 Tips

1. **For optimal experience**: Use Method 1 (automated installer)
2. **For developers**: Extract, modify source, rebuild with build-and-install.sh
3. **For servers**: Use Method 2 (direct .deb installation)
4. **For clusters**: Use the .deb file for batch installation

---

## 🎉 You're Ready!

After installation, you can:
- ✅ View system information anytime with `myapp`
- ✅ Switch languages with `myapp ru` / `myapp en`
- ✅ Share the .deb file with others
- ✅ Modify and rebuild the source code

**Enjoy MyApp!** 🚀

For detailed information, see README.md and INSTALL.md inside the archive.
