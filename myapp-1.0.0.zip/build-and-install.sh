#!/bin/bash

# Скрипт для сборки и установки MyApp пакета

set -e

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$REPO_DIR/myapp"

echo "🔨 Сборка MyApp пакета..."
cd "$APP_DIR"

# Очистка старых файлов
rm -f ../*.deb ../*.changes ../*.buildinfo ../.pybuild

# Сборка пакета
dpkg-buildpackage -us -uc

echo ""
echo "✅ Пакет успешно собран!"
echo ""
echo "📦 Установка пакета..."

# Поиск собранного .deb файла
DEB_FILE=$(find .. -maxdepth 1 -name "myapp_*.deb" -type f | head -1)

if [ -z "$DEB_FILE" ]; then
    echo "❌ Ошибка: .deb файл не найден!"
    exit 1
fi

echo "Найден: $DEB_FILE"
echo ""

# Установка пакета
sudo dpkg -i "$DEB_FILE"

echo ""
echo "✅ MyApp успешно установлен!"
echo ""
echo "📝 Использование:"
echo "   myapp"
echo ""
